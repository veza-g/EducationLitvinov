﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FRAGMENTSTREE_PLG
{
    public class ExcelObject
    {
        public string Наименование { get; set; }
        public string Обозначение { get; set; }
        public string Нестандартные { get; set; }
        public string Размер { get; set; }
    }
}
